"""
clean_aterio.py
===============
Cleans and integrates the Aterio.io US Data Center Locations and Power Demand
dataset (from Databricks Marketplace) into the project's master facility table.

What this script does
─────────────────────
1. Loads the Aterio CSV (auto-detects common column name variants)
2. Standardises facility name, location, and power demand fields
3. Flags data quality issues (missing coordinates, zero/null MW, duplicates)
4. Exports a cleaned Aterio-only table
5. (Optional) Merges MW values into the existing OSDC+FracTracker master
   dataset using fuzzy spatial matching (≤ 5 km) + name similarity

Expected Aterio columns (names may vary — the script maps common variants):
  - facility/data_center name
  - city, state, latitude, longitude
  - power capacity (MW) and/or power demand (MW)
  - operator/owner (if present)

Output files
────────────
  aterio_cleaned.csv             – cleaned Aterio-only table
  aterio_cleaning_report.txt     – data quality summary
  master_with_power.csv          – (if --master supplied) merged master dataset

Usage
─────
  python clean_aterio.py \
      --aterio  /path/to/aterio_data.csv \
      --master  /path/to/osdc_fractracker_combined.csv   # optional \
      --out     /path/to/output_directory
"""

import argparse
import os
import re
import sys
import warnings

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

# ── Column name aliases ────────────────────────────────────────────────────────
# Maps common Aterio column variants → canonical project names

NAME_ALIASES = [
    "name", "facility_name", "data_center_name", "datacenter_name",
    "data center name", "facility", "site_name",
]
CITY_ALIASES = ["city", "city_name", "municipality"]
STATE_ALIASES = ["state", "state_abbr", "state_name", "us_state"]
LAT_ALIASES   = ["latitude", "lat", "y", "lat_dd"]
LON_ALIASES   = ["longitude", "lon", "lng", "long", "x", "lon_dd"]
MW_ALIASES    = [
    "power_mw", "power_demand_mw", "capacity_mw", "mw", "power_capacity",
    "total_mw", "it_load_mw", "critical_load_mw", "demand_mw",
]
OPERATOR_ALIASES = ["operator", "owner", "company", "provider", "tenant"]
YEAR_ALIASES = [
    "year_built", "year_opened", "construction_year", "online_year",
    "commissioned_year",
]


def _find_col(df: pd.DataFrame, aliases: list) -> str | None:
    """Return the first column in df that matches any alias (case-insensitive)."""
    lower_map = {c.lower().strip(): c for c in df.columns}
    for alias in aliases:
        if alias.lower() in lower_map:
            return lower_map[alias.lower()]
    return None


# ── Cleaning helpers ───────────────────────────────────────────────────────────

def standardise_name(s: pd.Series) -> pd.Series:
    return (
        s.astype(str)
        .str.strip()
        .str.replace(r"\s+", " ", regex=True)
        .str.title()
        .replace("Nan", np.nan)
    )


def standardise_state(s: pd.Series) -> pd.Series:
    """Convert full state names to 2-letter USPS codes where possible."""
    STATE_MAP = {
        "alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR",
        "california": "CA", "colorado": "CO", "connecticut": "CT",
        "delaware": "DE", "florida": "FL", "georgia": "GA", "hawaii": "HI",
        "idaho": "ID", "illinois": "IL", "indiana": "IN", "iowa": "IA",
        "kansas": "KS", "kentucky": "KY", "louisiana": "LA", "maine": "ME",
        "maryland": "MD", "massachusetts": "MA", "michigan": "MI",
        "minnesota": "MN", "mississippi": "MS", "missouri": "MO",
        "montana": "MT", "nebraska": "NE", "nevada": "NV",
        "new hampshire": "NH", "new jersey": "NJ", "new mexico": "NM",
        "new york": "NY", "north carolina": "NC", "north dakota": "ND",
        "ohio": "OH", "oklahoma": "OK", "oregon": "OR", "pennsylvania": "PA",
        "rhode island": "RI", "south carolina": "SC", "south dakota": "SD",
        "tennessee": "TN", "texas": "TX", "utah": "UT", "vermont": "VT",
        "virginia": "VA", "washington": "WA", "west virginia": "WV",
        "wisconsin": "WI", "wyoming": "WY", "district of columbia": "DC",
    }
    cleaned = s.astype(str).str.strip().str.upper()
    # if already 2-letter, leave it
    mask_long = cleaned.str.len() > 2
    cleaned[mask_long] = cleaned[mask_long].str.lower().map(STATE_MAP).fillna(
        cleaned[mask_long]
    )
    return cleaned


def clean_mw(s: pd.Series) -> pd.Series:
    """Strip units/commas, convert to float, set implausible values to NaN."""
    cleaned = (
        s.astype(str)
        .str.replace(r"[^\d\.]", "", regex=True)
        .replace("", np.nan)
    )
    numeric = pd.to_numeric(cleaned, errors="coerce")
    # zero or negative MW is data quality issue
    numeric = numeric.where(numeric > 0, other=np.nan)
    # very large values (>10,000 MW for a single facility) are likely errors
    numeric = numeric.where(numeric <= 10_000, other=np.nan)
    return numeric


def haversine_km(lat1, lon1, lat2, lon2):
    """Vectorised haversine distance in km."""
    R = 6371.0
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return 2 * R * np.arcsin(np.sqrt(a))


# ── Main pipeline ─────────────────────────────────────────────────────────────

def load_aterio(path: str) -> pd.DataFrame:
    print(f"[1/5] Loading Aterio dataset: {path}")
    try:
        df = pd.read_csv(path, low_memory=False)
    except Exception:
        df = pd.read_csv(path, encoding="latin-1", low_memory=False)
    print(f"      Raw shape: {df.shape[0]:,} rows × {df.shape[1]} columns")
    print(f"      Columns: {list(df.columns)}")
    return df


def map_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Detect and rename key columns to canonical names."""
    print("[2/5] Mapping columns …")
    mapping = {}
    for aliases, canonical in [
        (NAME_ALIASES,     "dc_name"),
        (CITY_ALIASES,     "city"),
        (STATE_ALIASES,    "state"),
        (LAT_ALIASES,      "latitude"),
        (LON_ALIASES,      "longitude"),
        (MW_ALIASES,       "power_mw"),
        (OPERATOR_ALIASES, "operator"),
        (YEAR_ALIASES,     "year_built"),
    ]:
        col = _find_col(df, aliases)
        if col:
            mapping[col] = canonical
            print(f"      '{col}' → '{canonical}'")
        else:
            print(f"      ⚠  No column found for '{canonical}' — will be NaN")

    df = df.rename(columns=mapping)

    # ensure all canonical columns exist
    for canon in ["dc_name","city","state","latitude","longitude",
                  "power_mw","operator","year_built"]:
        if canon not in df.columns:
            df[canon] = np.nan

    return df


def clean_fields(df: pd.DataFrame) -> pd.DataFrame:
    print("[3/5] Cleaning fields …")
    df = df.copy()

    df["dc_name"]   = standardise_name(df["dc_name"])
    df["city"]      = standardise_name(df["city"])
    df["state"]     = standardise_state(df["state"])
    df["operator"]  = standardise_name(df["operator"])
    df["latitude"]  = pd.to_numeric(df["latitude"],  errors="coerce")
    df["longitude"] = pd.to_numeric(df["longitude"], errors="coerce")
    df["power_mw"]  = clean_mw(df["power_mw"])

    # year
    df["year_built"] = pd.to_numeric(
        df["year_built"].astype(str).str.extract(r"(\d{4})")[0],
        errors="coerce"
    )
    df["year_built"] = df["year_built"].where(
        df["year_built"].between(1960, 2030), other=np.nan
    )

    # temporal flag for AI expansion era
    df["post_ai_era"] = df["year_built"].apply(
        lambda y: True if (pd.notna(y) and y >= 2022) else (
                  False if pd.notna(y) else np.nan)
    )

    # data quality flags
    df["flag_no_coords"]  = df["latitude"].isna() | df["longitude"].isna()
    df["flag_no_power"]   = df["power_mw"].isna()
    df["flag_no_name"]    = df["dc_name"].isna()
    df["flag_no_year"]    = df["year_built"].isna()

    # source tag
    df["source"] = "aterio"

    return df


def deduplicate(df: pd.DataFrame) -> pd.DataFrame:
    print("[4/5] Deduplicating …")
    before = len(df)

    # exact name + state duplicates → keep the one with the most data
    df["_completeness"] = df[["power_mw","latitude","longitude","year_built"]].notna().sum(axis=1)
    df = (
        df.sort_values("_completeness", ascending=False)
          .drop_duplicates(subset=["dc_name","state"], keep="first")
          .drop(columns=["_completeness"])
    )
    print(f"      Removed {before - len(df):,} exact duplicates "
          f"({before:,} → {len(df):,})")
    return df


def quality_report(df: pd.DataFrame, out_dir: str) -> None:
    lines = []
    lines.append("=" * 60)
    lines.append("ATERIO DATASET CLEANING REPORT")
    lines.append("=" * 60)
    lines.append(f"\nFacilities after cleaning: {len(df):,}")
    lines.append(f"\nData completeness:")
    lines.append(f"  Has coordinates : {(~df['flag_no_coords']).sum():,}")
    lines.append(f"  Has power (MW)  : {(~df['flag_no_power']).sum():,}")
    lines.append(f"  Has year built  : {(~df['flag_no_year']).sum():,}")
    lines.append(f"  Has operator    : {df['operator'].notna().sum():,}")

    lines.append(f"\nPower demand (MW) — facilities with data:")
    mw = df["power_mw"].dropna()
    if len(mw):
        lines.append(f"  Count  : {len(mw):,}")
        lines.append(f"  Range  : {mw.min():.1f} – {mw.max():.1f} MW")
        lines.append(f"  Mean   : {mw.mean():.1f} MW")
        lines.append(f"  Median : {mw.median():.1f} MW")
        lines.append(f"  Total  : {mw.sum():.1f} MW")

    if df["year_built"].notna().any():
        lines.append(f"\nTemporal distribution:")
        yr = df["year_built"].dropna()
        for era, label in [
            ((yr < 2010),            "pre-2010"),
            ((yr >= 2010) & (yr < 2020), "2010–2019"),
            ((yr >= 2020) & (yr < 2022), "2020–2021"),
            ((yr >= 2022),           "2022+ (AI era)"),
        ]:
            lines.append(f"  {label:20s}: {era.sum():,}")

    if df["state"].notna().any():
        lines.append(f"\nTop 10 states by facility count:")
        top = df["state"].value_counts().head(10)
        for state, count in top.items():
            lines.append(f"  {state}: {count}")

    lines.append("\nINTEGRATION NOTES")
    lines.append("─────────────────")
    lines.append("• Join to master dataset by lat/lon proximity (≤ 5 km) OR")
    lines.append("  name fuzzy match (≥ 0.5 similarity), same as OSDC-FracTracker merge.")
    lines.append("• Power_mw values are facility capacity, not real-time demand.")
    lines.append("• Aterio pre-1980 data may be sparse; year_built NaN rate expected ~40%.")
    lines.append("• post_ai_era flag (year_built ≥ 2022) supports temporal analysis.")

    path = os.path.join(out_dir, "aterio_cleaning_report.txt")
    with open(path, "w") as f:
        f.write("\n".join(lines))
    print(f"\n      Quality report → {path}")
    print("\n".join(lines))


def merge_with_master(aterio: pd.DataFrame, master_path: str, out_dir: str) -> None:
    """
    Spatial + name-based merge to add Aterio MW values to the master dataset.
    Matches on: haversine distance ≤ 5km AND/OR name similarity ≥ 0.5.
    """
    print(f"\n[MERGE] Loading master dataset: {master_path}")
    master = pd.read_csv(master_path, low_memory=False)
    print(f"         Master shape: {master.shape}")

    # detect lat/lon in master
    lat_col = _find_col(master, LAT_ALIASES)
    lon_col = _find_col(master, LON_ALIASES)
    name_col = _find_col(master, NAME_ALIASES)

    if not lat_col or not lon_col:
        print("         ⚠  Cannot find lat/lon columns in master — skipping spatial merge.")
        return

    master["_lat"] = pd.to_numeric(master[lat_col], errors="coerce")
    master["_lon"] = pd.to_numeric(master[lon_col], errors="coerce")

    # only match Aterio rows with coordinates and MW data
    aterio_match = aterio.dropna(subset=["latitude","longitude","power_mw"]).copy()
    print(f"         Aterio rows with coords+MW: {len(aterio_match):,}")

    master["aterio_power_mw"]  = np.nan
    master["aterio_match_km"]  = np.nan
    master["aterio_year_built"] = np.nan

    matched = 0
    for _, row in aterio_match.iterrows():
        dist = haversine_km(
            master["_lat"].values, master["_lon"].values,
            row["latitude"], row["longitude"]
        )
        close = dist <= 5.0
        if close.any():
            idx = dist[close].idxmin()
            if pd.isna(master.at[idx, "aterio_power_mw"]):
                master.at[idx, "aterio_power_mw"]   = row["power_mw"]
                master.at[idx, "aterio_match_km"]   = dist[idx]
                master.at[idx, "aterio_year_built"] = row["year_built"]
                matched += 1

    pct = matched / len(aterio_match) * 100
    print(f"         Aterio facilities matched to master: {matched:,} / {len(aterio_match):,} ({pct:.1f}%)")

    master = master.drop(columns=["_lat","_lon"])
    out_path = os.path.join(out_dir, "master_with_aterio_power.csv")
    master.to_csv(out_path, index=False)
    print(f"         Merged master saved → {out_path}")


# ── Entry point ────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--aterio", required=True,
                        help="Path to Aterio CSV download")
    parser.add_argument("--master", default=None,
                        help="(Optional) path to OSDC+FracTracker master CSV")
    parser.add_argument("--out",    default=".",
                        help="Output directory")
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)

    df = load_aterio(args.aterio)
    df = map_columns(df)
    df = clean_fields(df)
    df = deduplicate(df)

    out_path = os.path.join(args.out, "aterio_cleaned.csv")
    df.to_csv(out_path, index=False)
    print(f"\n[5/5] Cleaned Aterio table saved → {out_path}")

    quality_report(df, args.out)

    if args.master:
        merge_with_master(df, args.master, args.out)

    print("\n✓ Done.")


if __name__ == "__main__":
    main()
