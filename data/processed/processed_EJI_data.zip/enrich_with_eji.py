"""
enrich_with_eji.py
==================
Extracts the three missing EJScreen-equivalent features from the CDC EJI 2024
dataset and produces a tract-level lookup table ready to merge into the
existing random-forest dataset.

EJScreen field  →  EJI equivalent used here
────────────────────────────────────────────
CANCER          →  E_CANCER   (modeled cancer prevalence %, adults 18+)
RESP            →  E_ASTHMA   (modeled asthma prevalence %, adults 18+;
                               best respiratory-burden proxy in EJI)
LDPNT           →  E_HOUAGE   (% housing units built before 1980;
                               EJI's lead-paint risk proxy — EJScreen uses
                               pre-1960, EJI uses pre-1980; note in docs)

Sentinel value: EJI encodes missing data as -999. These are converted to NaN.

GEOID note: EJI stores GEOID as an integer, which silently drops the leading
zero for states with FIPS < 10 (AL, AK, AZ, AR, CA, CO, CT, DE, FL, GA).
We zero-pad to 11 digits to match the standard census tract GEOID format used
by EJScreen and most spatial joins.

Outputs
───────
  eji_missing_features.csv        – tract-level table of the three new fields
                                    + percentile ranks + metadata
  eji_feature_summary.txt         – data quality report

Usage
─────
  python enrich_with_eji.py \
      --eji    /path/to/EJI_2024_United_States.csv \
      --rf     /path/to/random_forest_dataset.csv   \   # optional
      --out    /path/to/output_directory
"""

import argparse
import os
import sys
import pandas as pd
import numpy as np

# ── Column mapping ────────────────────────────────────────────────────────────

EJI_COLS = {
    # identifiers
    "GEOID":       "geoid_eji",          # will be zero-padded → geoid_11
    "STATEFP":     "state_fips",
    "STATEABBR":   "state_abbr",
    "COUNTY":      "county_name",

    # raw estimates  (units: %)
    "E_CANCER":    "CANCER_pct",         # EJScreen: CANCER
    "E_ASTHMA":    "RESP_pct",           # EJScreen: RESP  (asthma proxy)
    "E_HOUAGE":    "LDPNT_pct",          # EJScreen: LDPNT (pre-1980 housing)

    # percentile ranks (0–1 within national distribution, higher = worse)
    "EPL_CANCER":  "CANCER_pctile",
    "EPL_ASTHMA":  "RESP_pctile",
}

SENTINEL = -999          # EJI missing-data code
GEOID_LEN = 11           # standard census tract FIPS length


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_eji(path: str) -> pd.DataFrame:
    print(f"[1/5] Loading EJI dataset from: {path}")
    df = pd.read_csv(
        path,
        usecols=list(EJI_COLS.keys()),
        dtype={"GEOID": str, "STATEFP": str},   # keep as string for padding
        low_memory=False,
    )
    print(f"      Loaded {len(df):,} census tracts, {df.shape[1]} columns")
    return df


def clean_geoid(df: pd.DataFrame) -> pd.DataFrame:
    """Zero-pad GEOID to 11 digits (standard census tract format)."""
    print("[2/5] Standardising GEOID to 11-digit format …")
    df["geoid_11"] = df["GEOID"].str.strip().str.zfill(GEOID_LEN)
    # Sanity check
    bad = df["geoid_11"].str.len() != GEOID_LEN
    if bad.any():
        print(f"      ⚠  {bad.sum()} GEOIDs not 11 chars after padding — inspect these rows")
    else:
        print(f"      ✓  All {len(df):,} GEOIDs are 11 digits")
    return df


def replace_sentinels(df: pd.DataFrame, numeric_cols: list) -> pd.DataFrame:
    """Replace -999 sentinel with NaN."""
    print("[3/5] Replacing -999 sentinel values with NaN …")
    for col in numeric_cols:
        n = (df[col] == SENTINEL).sum()
        if n:
            df[col] = df[col].replace(SENTINEL, np.nan)
            print(f"      {col}: {n:,} sentinels → NaN  ({n/len(df)*100:.1f}% of tracts)")
    return df


def rename_and_select(df: pd.DataFrame) -> pd.DataFrame:
    """Rename to project-friendly names and drop raw GEOID."""
    print("[4/5] Renaming columns …")
    df = df.rename(columns=EJI_COLS)

    # compute LDPNT percentile rank ourselves (EJI doesn't pre-compute one)
    df["LDPNT_pctile"] = df["LDPNT_pct"].rank(pct=True, na_option="keep")

    # reorder
    out_cols = [
        "geoid_11",
        "state_fips", "state_abbr", "county_name",
        "CANCER_pct",  "CANCER_pctile",
        "RESP_pct",    "RESP_pctile",
        "LDPNT_pct",   "LDPNT_pctile",
    ]
    df = df[out_cols].copy()
    df = df.drop_duplicates(subset=["geoid_11"])
    return df


def quality_report(df: pd.DataFrame, out_dir: str) -> None:
    lines = []
    lines.append("=" * 60)
    lines.append("EJI MISSING-FEATURE EXTRACTION  —  DATA QUALITY REPORT")
    lines.append("=" * 60)
    lines.append(f"\nTotal census tracts: {len(df):,}")
    lines.append(f"Unique GEOIDs:        {df['geoid_11'].nunique():,}")
    lines.append("")

    feat_map = {
        "CANCER_pct":  ("CANCER",  "E_CANCER",  "Modelled cancer prevalence (%)"),
        "RESP_pct":    ("RESP",    "E_ASTHMA",  "Modelled asthma prevalence (%)"),
        "LDPNT_pct":   ("LDPNT",   "E_HOUAGE",  "% housing units built pre-1980"),
    }

    for col, (ejscreen_name, eji_name, description) in feat_map.items():
        s = df[col]
        n_null = s.isna().sum()
        lines.append(f"{'─'*55}")
        lines.append(f"EJScreen field : {ejscreen_name}")
        lines.append(f"EJI source col : {eji_name}")
        lines.append(f"Description    : {description}")
        lines.append(f"Missing        : {n_null:,}  ({n_null/len(df)*100:.1f}%)")
        lines.append(f"Valid range    : {s.min():.2f} – {s.max():.2f}")
        lines.append(f"Mean ± SD      : {s.mean():.2f} ± {s.std():.2f}")
        lines.append(f"Median         : {s.median():.2f}")
        lines.append("")

    lines.append("NOTES")
    lines.append("─────")
    lines.append("• CANCER and RESP come from CDC PLACES / BRFSS modelled estimates.")
    lines.append("  EJScreen uses air-toxics modelling (NATA); units differ.")
    lines.append("  Both measure population-level health burden at tract level.")
    lines.append("• LDPNT: EJScreen uses % pre-1960 housing; EJI uses pre-1980.")
    lines.append("  Pre-1980 captures more lead-paint risk (ban was 1978).")
    lines.append("  Document this assumption in your methods section.")
    lines.append("• Percentile ranks are national (not state-level).")
    lines.append("• -999 sentinel values have been converted to NaN.")

    report_path = os.path.join(out_dir, "eji_feature_summary.txt")
    with open(report_path, "w") as f:
        f.write("\n".join(lines))
    print(f"\n      Quality report saved → {report_path}")
    print("\n".join(lines))


def merge_with_rf(eji: pd.DataFrame, rf_path: str, out_dir: str) -> None:
    """Optional: merge new features into the existing random-forest dataset."""
    print(f"\n[MERGE] Loading random-forest dataset from: {rf_path}")
    rf = pd.read_csv(rf_path, dtype=str, low_memory=False)

    # detect GEOID column
    geoid_col = None
    for c in ["geoid_11", "GEOID", "geoid", "tract_geoid", "TRACTFIPS"]:
        if c in rf.columns:
            geoid_col = c
            break
    if geoid_col is None:
        print("      ⚠  Could not auto-detect GEOID column in RF dataset. "
              "Set geoid_col manually.")
        return

    rf[geoid_col] = rf[geoid_col].astype(str).str.zfill(GEOID_LEN)
    before = len(rf)
    merged = rf.merge(
        eji[["geoid_11","CANCER_pct","CANCER_pctile",
             "RESP_pct","RESP_pctile",
             "LDPNT_pct","LDPNT_pctile"]],
        left_on=geoid_col,
        right_on="geoid_11",
        how="left",
    )
    matched = merged["CANCER_pct"].notna().sum()
    print(f"      RF rows: {before:,} | matched EJI features: {matched:,} "
          f"({matched/before*100:.1f}%)")

    out_path = os.path.join(out_dir, "rf_dataset_with_eji_features.csv")
    merged.to_csv(out_path, index=False)
    print(f"      Merged RF dataset saved → {out_path}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--eji",  required=True,  help="Path to EJI_2024_United_States.csv")
    parser.add_argument("--rf",   default=None,   help="(Optional) path to existing RF dataset CSV")
    parser.add_argument("--out",  default=".",    help="Output directory (default: current dir)")
    args = parser.parse_args()

    os.makedirs(args.out, exist_ok=True)

    numeric_cols = ["E_CANCER", "E_ASTHMA", "E_HOUAGE", "EPL_CANCER", "EPL_ASTHMA"]

    df = load_eji(args.eji)
    df = clean_geoid(df)
    df = replace_sentinels(df, numeric_cols)
    df = rename_and_select(df)

    out_path = os.path.join(args.out, "eji_missing_features.csv")
    df.to_csv(out_path, index=False)
    print(f"\n[5/5] Saved EJI feature table ({len(df):,} tracts) → {out_path}")

    quality_report(df, args.out)

    if args.rf:
        merge_with_rf(df, args.rf, args.out)

    print("\n✓ Done.")


if __name__ == "__main__":
    main()
